class Student {

    int rollNo;
    String name;
    int age;
    String department;
    int semester;
    String email;
    String phone;
    String address;
    double cgpa;

    Student(int rollNo, String name, int age, String department,
            int semester, String email, String phone,
            String address, double cgpa) {

        this.rollNo = rollNo;
        this.name = name;
        this.age = age;
        this.department = department;
        this.semester = semester;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.cgpa = cgpa;
    }

    void display() {
        System.out.println("------------------------------");
        System.out.println("Roll No    : " + rollNo);
        System.out.println("Name       : " + name);
        System.out.println("Age        : " + age);
        System.out.println("Department : " + department);
        System.out.println("Semester   : " + semester);
        System.out.println("Email      : " + email);
        System.out.println("Phone      : " + phone);
        System.out.println("Address    : " + address);
        System.out.println("CGPA       : " + cgpa);
    }
}