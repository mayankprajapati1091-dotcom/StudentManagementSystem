import java.util.ArrayList;
import java.util.Scanner;

public class StudentManagementSystem {

    static Scanner sc = new Scanner(System.in);
    static ArrayList<Student> students = new ArrayList<>();

    public static void main(String[] args) {

        if (!login()) {
            System.out.println("Login Failed!");
            return;
        }

        while (true) {

            System.out.println("\n===== Student Management System =====");
            System.out.println("1. Add Student");
            System.out.println("2. View Students");
            System.out.println("3. Search Student");
            System.out.println("4. Update Student");
            System.out.println("5. Delete Student");
            System.out.println("6. Department Report");
            System.out.println("7. Semester Report");
            System.out.println("8. Exit");

            System.out.print("Enter Choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1:
                    addStudent();
                    break;

                case 2:
                    viewStudents();
                    break;

                case 3:
                    searchStudent();
                    break;

                case 4:
                    updateStudent();
                    break;

                case 5:
                    deleteStudent();
                    break;

                case 6:
                    departmentReport();
                    break;

                case 7:
                    semesterReport();
                    break;

                case 8:
                    System.out.println("Thank You!");
                    return;

                default:
                    System.out.println("Invalid Choice.");
            }
        }
    }

    // Login Method
    static boolean login() {

        System.out.println("===== Login =====");

        final int MAX_ATTEMPTS = 3;

        for (int attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {

            System.out.print("Username: ");
            String user = sc.nextLine().trim();

            System.out.print("Password: ");
            String pass = sc.nextLine().trim();

            // Username check is case-insensitive, password check is case-sensitive (by design)
            if (user.equalsIgnoreCase("admin") && pass.equals("1234")) {
                System.out.println("Login Successful!");
                return true;
            }

            // Tell the user exactly what mismatched instead of a silent generic failure
            if (!user.equalsIgnoreCase("admin")) {
                System.out.println("Incorrect username.");
            } else {
                System.out.println("Incorrect password.");
            }

            if (attempt < MAX_ATTEMPTS) {
                System.out.println("Attempts remaining: " + (MAX_ATTEMPTS - attempt));
            }
        }

        return false;
    }

    static void addStudent() {

        System.out.print("Roll Number: ");
        int roll = sc.nextInt();
        sc.nextLine();

        for (Student s : students) {
            if (s.rollNo == roll) {
                System.out.println("Duplicate Roll Number!");
                return;
            }
        }

        System.out.print("Name: ");
        String name = sc.nextLine();

        System.out.print("Age: ");
        int age = sc.nextInt();
        sc.nextLine();

        System.out.print("Department: ");
        String dept = sc.nextLine();

        System.out.print("Semester: ");
        int sem = sc.nextInt();
        sc.nextLine();

        System.out.print("Email: ");
        String email = sc.nextLine();

        if (!email.contains("@")) {
            System.out.println("Invalid Email.");
            return;
        }

        System.out.print("Phone: ");
        String phone = sc.nextLine();

        if (phone.length() != 10) {
            System.out.println("Phone must have 10 digits.");
            return;
        }

        System.out.print("Address: ");
        String address = sc.nextLine();

        System.out.print("CGPA: ");
        double cgpa = sc.nextDouble();
        sc.nextLine();

        if (cgpa < 0 || cgpa > 10) {
            System.out.println("CGPA must be between 0 and 10.");
            return;
        }

        students.add(new Student(roll, name, age, dept, sem, email, phone, address, cgpa));

        System.out.println("Student Added Successfully!");
    }

    static void viewStudents() {

        if (students.isEmpty()) {
            System.out.println("No Students Found.");
            return;
        }

        for (Student s : students) {
            s.display();
        }
    }

    static void searchStudent() {

        System.out.print("Enter Roll Number: ");
        int roll = sc.nextInt();
        sc.nextLine();

        for (Student s : students) {
            if (s.rollNo == roll) {
                s.display();
                return;
            }
        }

        System.out.println("Student Not Found.");
    }

    static void updateStudent() {

        System.out.print("Enter Roll Number: ");
        int roll = sc.nextInt();
        sc.nextLine();

        for (Student s : students) {

            if (s.rollNo == roll) {

                System.out.print("New Name: ");
                s.name = sc.nextLine();

                System.out.print("New Age: ");
                s.age = sc.nextInt();
                sc.nextLine();

                System.out.print("New Department: ");
                s.department = sc.nextLine();

                System.out.print("New Semester: ");
                s.semester = sc.nextInt();
                sc.nextLine();

                System.out.print("New CGPA: ");
                s.cgpa = sc.nextDouble();
                sc.nextLine();

                System.out.println("Student Updated!");
                return;
            }
        }

        System.out.println("Student Not Found.");
    }

    static void deleteStudent() {

        System.out.print("Enter Roll Number: ");
        int roll = sc.nextInt();
        sc.nextLine();

        for (Student s : students) {

            if (s.rollNo == roll) {

                students.remove(s);

                System.out.println("Student Deleted!");
                return;
            }
        }

        System.out.println("Student Not Found.");
    }

    static void departmentReport() {

        System.out.print("Enter Department: ");
        String dept = sc.nextLine();

        boolean found = false;

        for (Student s : students) {
            if (s.department.equalsIgnoreCase(dept)) {
                s.display();
                found = true;
            }
        }

        if (!found) {
            System.out.println("No students found.");
        }
    }

    static void semesterReport() {

        System.out.print("Enter Semester: ");
        int sem = sc.nextInt();
        sc.nextLine();

        boolean found = false;

        for (Student s : students) {
            if (s.semester == sem) {
                s.display();
                found = true;
            }
        }

        if (!found) {
            System.out.println("No students found.");
        }
    }
}